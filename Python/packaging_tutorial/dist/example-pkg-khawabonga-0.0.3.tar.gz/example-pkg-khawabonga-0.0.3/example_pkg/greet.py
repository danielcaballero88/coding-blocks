def SayHello(name):
    print("Hello " + name + "!")
    return

def SayGoodbye(name):
    print("Goodbye " + name + "!") 
    return
